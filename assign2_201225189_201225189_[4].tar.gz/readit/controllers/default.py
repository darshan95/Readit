# -*- coding: utf-8 -*-
# this file is released under public domain and you can use without limitations

#########################################################################
## This is a samples controller
## - index is the default action of any application
## - user is required for authentication and authorization
## - download is for downloading files uploaded in the db (does streaming)
## - call exposes all registered services (none by default)
#########################################################################
#from gluon import current
#auth.settings.register_next=URL('user_details')
from gluon import current
auth.settings.create_user_groups = False

def index():
    """
    example action using the internationalization operator T and flash
    rendered by views/default/index.html or views/generic.html

    if you need a simple wiki simple replace the two lines below with:
    return auth.wiki()
    """
#    session.user_id=auth.user.id
#    session.user_name=auth.user.first_name
    if auth.has_membership(role='admin'):
        redirect(URL('admin_interface'))
    cat = db(db.category.id>0).select(db.category.id,db.category.name)
    news = db(db.news_item.id>0).select(db.news_item.category_id,db.news_item.Heading,db.news_item.url,db.news_item.id,db.news_item.created_by,db.news_item.likes_no,db.news_item.dislikes_no,db.news_item.rank_item,db.news_item.created_on,db.news_item.video_url,orderby=~db.news_item.rank_item)
    news_url = db(db.news_item.id>0).select(db.news_item.url)    
    return dict(news=news,cat=cat)

def groupadd(check_group):
		if not db(db.auth_group.role==check_group).count():
				db.auth_group.insert(role=check_group)
			
#def play_video():
 #   video = db.news_item.video_url(request.args(0))
  #  return dict(video=video)
    
@auth.requires_login()
@auth.requires_membership('admin')
def admin_interface():
    cat = db(db.category.id>0).select(db.category.id,db.category.name)
    news = db(db.news_item.id>0).select(db.news_item.category_id,db.news_item.Heading,db.news_item.url,db.news_item.id,db.news_item.created_by,db.news_item.likes_no,db.news_item.dislikes_no,db.news_item.created_on,db.news_item.video_url, orderby = ~db.news_item.rank_item)    
    return dict(news=news,cat=cat)


#@auth.requires_login()
#def user_details():
 #   groupadd('user')
  #  auth.add_membership(auth.id_group('user'),session.user_id)
   # session.user_id=auth.user.id
    #session.user_name=auth.user.first_name
    #redirect(URL('index'))


def user():
    """
    exposes:
    http://..../[app]/default/user/login
    http://..../[app]/default/user/logout
    http://..../[app]/default/user/register
    http://..../[app]/default/user/profile
    http://..../[app]/default/user/retrieve_password
    http://..../[app]/default/user/change_password
    use @auth.requires_login()
        @auth.requires_membership('group name')
        @auth.requires_permission('read','table name',record_id)
    to decorate functions that need access control
    """    
    auth.settings.register_onaccept = __add_user_membership

    return dict(form=auth())

def __add_user_membership(form):
    groupadd('user')
    user_id = form.vars.id 
    auth.add_membership(auth.id_group('user'),user_id)
         #group = db(db.auth_group.role==form.vars.Member_type).select().first()
         #user_id = form.vars.id
         #auth.add_membership(group.id,user_id)



def download():
    """
    allows downloading of uploaded files
    http://..../[app]/default/download/[filename]
    """
    return response.download(request, db)


def call():
    """
    exposes services. for example:
    http://..../[app]/default/call/jsonrpc
    decorate with @services.jsonrpc the functions to expose
    supports xml, json, xmlrpc, jsonrpc, amfrpc, rss, csv
    """
    return service()


@auth.requires_signature()
def data():
    """
    http://..../[app]/default/data/tables
    http://..../[app]/default/data/create/[table]
    http://..../[app]/default/data/read/[table]/[id]
    http://..../[app]/default/data/update/[table]/[id]
    http://..../[app]/default/data/delete/[table]/[id]
    http://..../[app]/default/data/select/[table]
    http://..../[app]/default/data/search/[table]
    but URLs must be signed, i.e. linked with
      A('table',_href=URL('data/tables',user_signature=True))
    or with the signed load operator
      LOAD('default','data.load',args='tables',ajax=True,user_signature=True)
    """
    return dict(form=crud())

@auth.requires_login()
def create():
    form = SQLFORM(db.news_item) if auth.user else none
#    z = db(db.like_dislike.newsitem_id == form.vars.id).select()
 #   y = db(db.auth_user.id>0).select(db.auth_user.id)
 #  for i in y:
  #     db.like_dislike.insert(newsitem_id = form.vars.id, userid = i, is_liked = 0)
    if form.accepts(request.vars,session):
        session.flash = 'submitted'
        redirect(URL('index',args=request.args))
        #session.flash = 'submitted'
    elif form.errors:
        session.flash = "Errors in Form"
    return dict(form=form)

@auth.requires_login()
def commentt():
    this_item = db.news_item(request.args(0,cast=int)) or redirect(URL('index'))
    db.Comments.newsitem_id.default = this_item.id
    form = SQLFORM(db.Comments) if auth.user else None
    itemcomments = db(db.Comments.newsitem_id==this_item.id).select()
    if form.accepts(request.vars,session):
        #redirect(URL('index'))
        session.flash = "comment posted"
        redirect(URL('commentt',args=request.args))
    elif form.errors:
        session.flash = "Errors in Form"
    return dict(item=this_item, itemcomments=itemcomments, form=form, var=this_item.url)

@auth.requires_login()
@auth.requires_membership('admin')
def add_category():
    form = SQLFORM(db.category)
#    grid=SQLFORM.smartgrid(db.Comments,linked_tables=['Comments'])

    if form.accepts(request.vars,session):
        session.flash = "Category added successfully"
        redirect(URL('admin_interface'))
    elif form.errors:
         session.flash = "Errors in form"
    return dict(form=form)

@auth.requires_login()
@auth.requires_membership('admin')
def delete_user():
    a = set([])
    b=set([])
#    for i in db.auth_user.id:
 #       z = i.id
        #print i
  #      if z!=10:
   #         y=db(db.auth_user.id==i.id).select(db.auth_user.first_name)
    #        a.add(y[0].first_name) """
    users = db(db.auth_user.id!=10).select(db.auth_user.first_name,db.auth_user.email)
    for i in users:
        a.add(i.first_name)
        b.add(i.email)
    form = SQLFORM.factory(Field('first_name',label = 'first name', requires = IS_IN_SET(a)),
                           Field('email',label  = 'email_id', requires = IS_IN_SET(b)))
    if form.accepts(request.vars,session):
        z = db((db.auth_user.email == form.vars.email) & (db.auth_user.first_name == form.vars.first_name)).select(db.auth_user.id)
        if z:
            items = db(z[0].id == db.like_dislike.userid).select(db.like_dislike.newsitem_id,db.like_dislike.is_liked) 
            for item in items:
                num=db(item.newsitem_id == db.news_item.id).select(db.news_item.likes_no,db.news_item.dislikes_no,db.news_item.rank_item)
#            var = db((this_item.id == db.like_dislike.newsitem_id) & (auth.user.id == db.like_dislike.userid)).select(db.like_dislike.is_liked)
                if item.is_liked == 1:
                    a = num[0].rank_item
                    a = a - 5
                    b = num[0].likes_no
                    b = b - 1
                    db(item.newsitem_id==db.news_item.id).update(rank_item=a,likes_no=b)
                #num[0].likes_no = num[0].likes_no-1
                #num[0].rank = num[0].rank-5
                elif item.is_liked == 2:
                    a = num[0].rank_item
                    a = a + 3
                    b = num[0].dislikes_no
                    b = b - 1
                    db(item.newsitem_id==db.news_item.id).update(rank_item=a,likes_no=b)
            db((db.auth_user.email == form.vars.email) & (db.auth_user.first_name == form.vars.first_name)).delete()
            session.flash = T("Deleted")
            redirect(URL('index'))
        else:
            response.flash = "Not a valid email id or first name"
    elif form.errors:
        session.flash = T("Errors in form")
    return dict(form=form)


@auth.requires_login()
def edit():
    this_item = db.news_item(request.args(0,cast=int)) or redirect(URL('index'))
    db.news_item.id.default = this_item
  #  if auth.user.id == this_item.created_by:
    form = SQLFORM(db.news_item,this_item)
   # next = URL('index',args=request.args))
    if form.accepts(request.vars,session):
        session.flash = "edited"
        redirect(URL('index',args=request.args))
    elif form.errors:
        session.flash = "Errors in Form"
    return dict(form=form)
   # else:
    #    redirect(URL('index'))

@auth.requires_login()        
def delete():
    this_item = db.news_item(request.args(0,cast=int)) or redirect(URL('index'))
   # if auth.user.id == this_item.created_by:
    db(db.news_item.id == this_item.id).delete()
        #return dict(msg = "deleted")
    session.flash=T("Deleted")
    redirect(URL('index'))
    session.flash=T("Deleted")
  #  else:
   #     response.flash = T("Do not have required permissions")
    #    redirect(URL('index'))

@auth.requires_login()
@auth.requires_membership('admin')
def delete_category():
    this_category = db.category(request.args(0,cast=int)) or redirect(URL('index'))
    db(db.category.id == this_category.id).delete()
    session.flash = T("Deleted")
    redirect(URL('index'))

@auth.requires_login()
def like():
    this_item = db.news_item(request.args(0,cast=int)) or redirect(URL('index'))
    db.like_dislike.newsitem_id.default = this_item.id
    f = 0
#    if (auth.user):
    var = db((this_item.id == db.like_dislike.newsitem_id) & (auth.user.id == db.like_dislike.userid)).select(db.like_dislike.is_liked)
    if var:
        if var[0].is_liked==0:
            a=1
            db((this_item.id == db.like_dislike.newsitem_id) & (auth.user.id == db.like_dislike.userid)).update(is_liked=1)
            var1 = db(this_item.id == db.news_item.id).select(db.news_item.likes_no,db.news_item.rank_item)
            a = var1[0].likes_no
            a = a+1
            b = var1[0].rank_item
            b = b + 5
            db(this_item.id == db.news_item.id).update(likes_no = a, rank_item = b)
            f = 1
         #   response.flash = "liked"
        elif var[0].is_liked==2:
            f = 2
        elif var[0].is_liked==1:
            a=1
            db((this_item.id == db.like_dislike.newsitem_id) & (auth.user.id == db.like_dislike.userid)).update(is_liked=0)
            var1 = db(this_item.id == db.news_item.id).select(db.news_item.likes_no,db.news_item.rank_item)
            a = var1[0].likes_no
            a = a-1
            b = var1[0].rank_item
            b = b - 5
            db(this_item.id == db.news_item.id).update(likes_no = a, rank_item = b)
            f = 3
          #  session.flash = "Already liked"
			#var.is_liked = 1
			#db.news_item.update(likes_no=likes_no+1)
    else:
        db.like_dislike.insert(newsitem_id = this_item.id, userid = auth.user.id, is_liked = 1)
        var1 = db(this_item.id == db.news_item.id).select(db.news_item.likes_no,db.news_item.rank_item)
        a = var1[0].likes_no
        a = a+1
        b = var1[0].rank_item
        b = b + 5
        f = 1
        db(this_item.id == db.news_item.id).update(likes_no = a, rank_item = b)
    #    session.flash = "liked"
    if f==2:
        session.flash = "You had Disliked this post earlier, to neutralise it click on dislike."
        redirect(URL('index'))
    elif f==1:
        session.flash = "Liked"
        redirect(URL('index'))
    elif f==3:
         session.flash = "You have neutalised your like to this post"
         redirect(URL('index'))
 #   response.flash = T("hello")
 #   redirect(URL('index'))




@auth.requires_login()
def dislike():
    this_item = db.news_item(request.args(0,cast=int)) or redirect(URL('index'))
    db.like_dislike.newsitem_id.default = this_item.id
    f=0
#    if (auth.user):
    var = db((this_item.id == db.like_dislike.newsitem_id) & (auth.user.id == db.like_dislike.userid)).select(db.like_dislike.is_liked)
    if var:
        if var[0].is_liked==0 :
            #a=2
            db((this_item.id == db.like_dislike.newsitem_id) & (auth.user.id == db.like_dislike.userid)).update(is_liked=2)
            var1 = db(this_item.id == db.news_item.id).select(db.news_item.dislikes_no,db.news_item.rank_item)
            a = var1[0].dislikes_no
            a = a+1
            b = var1[0].rank_item
            b = b-3 
            db(this_item.id == db.news_item.id).update(dislikes_no = a,rank_item=b)
            f=1

        elif var[0].is_liked == 2:
            db((this_item.id == db.like_dislike.newsitem_id) & (auth.user.id == db.like_dislike.userid)).update(is_liked=0)
            var1 = db(this_item.id == db.news_item.id).select(db.news_item.dislikes_no,db.news_item.rank_item)
            a = var1[0].dislikes_no
            a = a-1
            b = var1[0].rank_item
            b = b+3 
            db(this_item.id == db.news_item.id).update(dislikes_no = a,rank_item=b)
            f=3
            #session.flash = "Already disliked"
			#var.is_liked = 1
			#db.news_item.update(likes_no=likes_no+1)
        elif var[0].is_liked == 1:
            f=2
    else:
        db.like_dislike.insert(newsitem_id = this_item.id, userid = auth.user.id, is_liked = 2)
        var1 = db(this_item.id == db.news_item.id).select(db.news_item.dislikes_no,db.news_item.rank_item)
        a = var1[0].dislikes_no
        a = a+1
        b = var1[0].rank_item
        b = b-3 
        db(this_item.id == db.news_item.id).update(dislikes_no = a,rank_item=b)
        f=1
    if f==2:
        session.flash = "You had liked this post, first unlike it by clicking  on like."
        redirect(URL('index'))
    elif f==1:
        session.flash = "Disiked"
        redirect(URL('index'))
    elif f==3:
        session.flash = "You have neutralised your dislike to this post"
        redirect(URL('index'))
